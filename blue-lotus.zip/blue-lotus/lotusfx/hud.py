import pygame

TEXT = (150, 200, 255)
DIM = (70, 120, 210)
HELP = ["MOUSE tilt   CLICK pulse   SPACE regrow   N new flower",
        "L loop   LEFT/RIGHT scrub   +/- speed   T theme",
        "B glow   P pause   S shot   R rec   H hud   F full"]


class Hud:
    def __init__(self):
        self.big = pygame.font.Font(None, 22)
        self.small = pygame.font.Font(None, 18)

    def draw(self, screen, fps, dots, seed, theme, recording, percent, loop, speed):
        h = screen.get_height()
        tag = "  [REC]" if recording else ""
        screen.blit(self.big.render(f"BLUE LOTUS{tag}", True, TEXT), (12, 10))
        info = f"{fps:4.0f} fps   {dots:,} dots   seed {seed}   {theme}   growth {percent:3.0f}%   x{speed:.1f}"
        if loop:
            info += "   loop"
        screen.blit(self.small.render(info, True, DIM), (12, 30))
        for i, line in enumerate(HELP):
            screen.blit(self.small.render(line, True, DIM), (12, h - 16 * (len(HELP) - i) - 8))
