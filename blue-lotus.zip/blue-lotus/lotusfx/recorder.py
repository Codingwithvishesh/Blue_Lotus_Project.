"""Pipes raw RGB frames to ffmpeg -> H.264 MP4 (Instagram Reels friendly)."""
import shutil
import subprocess

import numpy as np


def find_ffmpeg():
    exe = shutil.which("ffmpeg")
    if exe:
        return exe
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        raise RuntimeError("ffmpeg not found. Run: pip install imageio-ffmpeg")


class Recorder:
    def __init__(self, path, width, height, fps):
        if width % 2 or height % 2:
            raise ValueError("Video width and height must be even numbers.")
        self.path = path
        cmd = [find_ffmpeg(), "-y", "-loglevel", "error",
               "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{width}x{height}",
               "-r", str(fps), "-i", "-", "-an",
               "-c:v", "libx264", "-preset", "medium", "-crf", "16",
               "-pix_fmt", "yuv420p", "-movflags", "+faststart", path]
        self.proc = subprocess.Popen(cmd, stdin=subprocess.PIPE)

    def write(self, frame):
        self.proc.stdin.write(np.ascontiguousarray(frame).tobytes())

    def close(self):
        if self.proc.stdin:
            self.proc.stdin.close()
        self.proc.wait()
