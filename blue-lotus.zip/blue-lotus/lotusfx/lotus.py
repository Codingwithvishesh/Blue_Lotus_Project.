"""The lotus: stippled petals, stamens, stem, leaves, soil and a dotted glass sphere.

Everything is a cloud of dots with (position, alpha, material, size).  Petals are
parametric lanceolate surfaces (a = along the petal, v = across), opened by a
growth value g in [0, 1].  The sphere is six great circles (icosahedral axes)
plus stars and orbiting motes, rotated in 3D and perspective projected.
"""
import numpy as np

TAU = 2.0 * np.pi
_f = np.float32
CAM = 3.5
GROUND = -1.45


def smooth(x):
    x = np.clip(x, 0.0, 1.0)
    return x * x * (3 - 2 * x)


def petal_w(a):
    return np.sin(np.pi * np.clip(a, 0, 1) ** 0.7) ** 0.85


def leaf_w(a):
    return np.sin(np.pi * np.clip(a, 0, 1) ** 0.75) ** 0.85


def sample_profile(prof, n, rng):
    a = np.linspace(0, 1, 512)
    c = np.cumsum(prof(a) + 1e-6)
    return np.interp(rng.random(n), c / c[-1], a)


def rot(x, y, z, yaw, tilt):
    c, s = np.cos(yaw), np.sin(yaw)
    x1, z1 = x * c + z * s, -x * s + z * c
    ct, st = np.cos(tilt), np.sin(tilt)
    return x1, y * ct - z1 * st, y * st + z1 * ct


def project(x, y, z):
    f = CAM / (CAM - z)
    return x * f, y * f, f


SIZES = np.array([1.0, 2.0, 3.0])


class Lotus:
    def __init__(self, seed=5, density=1.0):
        rng = self.rng = np.random.default_rng(seed)
        self.seed, self.d = seed, density
        self._petals(rng)
        self._stamens(rng)
        self._stem(rng)
        self._leaves(rng)
        self._soil(rng)
        self._shell(rng)
        self.kick = self.kick_v = 0.0
        self.emit_pos = np.zeros((0, 2)); self.emit_alpha = np.zeros(0); self.emit_row = np.zeros(0, int)
        self.head = np.zeros(2)

    # ----------------------------------------------------------------- build
    def _petals(self, rng):
        d, n0 = self.d, int(rng.integers(8, 11))
        self.row_n = np.array([n0, n0 - 1, 7, 5])
        self.row_L = np.array([0.78, 0.64, 0.50, 0.36])
        self.row_W = np.array([0.34, 0.29, 0.23, 0.17])
        self.row_thc = np.array([0.18, 0.14, 0.10, 0.06])
        self.row_tho = np.array([1.28, 1.00, 0.72, 0.42]) + rng.uniform(-0.05, 0.05, 4)
        self.row_bend = np.array([0.28, 0.12, -0.12, -0.25])
        self.row_r0 = np.array([0.06, 0.045, 0.03, 0.02])
        self.row_mat = np.array([0.38, 0.50, 0.63, 0.75])
        self.row_ph = rng.uniform(0, TAU, 4)
        per_petal = (np.array([1100, 850, 420, 220]) * d).astype(int)

        A, V, ROW, PET, MT, SZ, AL = [], [], [], [], [], [], []
        for r in range(4):
            tot = per_petal[r] * self.row_n[r]
            kind = rng.choice(3, tot, p=[0.66, 0.24, 0.10])
            a = np.where(kind == 0, sample_profile(petal_w, tot, rng), rng.uniform(0.02, 0.98, tot))
            v = np.where(kind == 0, rng.uniform(-1, 1, tot),
                         np.where(kind == 1, rng.choice([-1.0, 1.0], tot) * (1 - rng.random(tot) * 0.04),
                                  rng.normal(0, 0.03, tot)))
            mt = self.row_mat[r] + 0.14 * (1 - a) + 0.06 * (1 - np.abs(v)) + rng.normal(0, 0.025, tot)
            mt = mt - 0.05 * (kind == 1) + 0.06 * (kind == 2)
            A.append(a); V.append(v); ROW.append(np.full(tot, r))
            PET.append(np.repeat(np.arange(self.row_n[r]), per_petal[r]))
            MT.append(np.clip(mt, 0.3, 0.82))
            SZ.append(rng.choice(SIZES, tot, p=[0.25, 0.45, 0.30]))
            AL.append(np.where(kind == 0, 0.60 + 0.40 * rng.random(tot), np.where(kind == 1, 0.6 + 0.2 * rng.random(tot), 0.5)))
        cat = np.concatenate
        self.pA, self.pV, self.pROW, self.pPET = cat(A), cat(V), cat(ROW), cat(PET)
        self.pMT, self.pSZ, self.pAL = cat(MT), cat(SZ), cat(AL)
        self.pPHI = self.row_ph[self.pROW] + TAU * self.pPET / self.row_n[self.pROW]
        self.pTW = rng.uniform(0, TAU, len(self.pA))

    def _stamens(self, rng):
        nf, m = int(46 * self.d), 8
        self.nf, self.m = nf, m
        k = np.tile(np.linspace(0, 1, m), nf)
        fid = np.repeat(np.arange(nf), m)
        self.s_k = k
        self.s_rr = rng.uniform(0.01, 0.09, nf)[fid]
        self.s_phi = rng.uniform(0, TAU, nf)[fid]
        self.s_tl = rng.uniform(0.05, 0.55, nf)[fid]
        self.s_len = rng.uniform(0.12, 0.22, nf)[fid]
        self.s_sz = np.where(k > 0.999, 3.0, 1.0)
        self.s_tw = rng.uniform(0, TAU, nf * m)
        nd = int(150 * self.d)
        rr = np.sqrt(rng.random(nd)) * 0.08
        ph = rng.uniform(0, TAU, nd)
        self.disk = np.stack([rr * np.cos(ph), np.full(nd, 0.03), rr * np.sin(ph)], 1)
        self.disk_tw = rng.uniform(0, TAU, nd)

    def _bez(self, u):
        P = self.P
        q = 1 - u
        return (q ** 3)[..., None] * P[0] + (3 * q * q * u)[..., None] * P[1] \
            + (3 * q * u * u)[..., None] * P[2] + (u ** 3)[..., None] * P[3]

    def _tan(self, u):
        P = self.P
        q = 1 - u
        t = (3 * q * q)[..., None] * (P[1] - P[0]) + (6 * q * u)[..., None] * (P[2] - P[1]) \
            + (3 * u * u)[..., None] * (P[3] - P[2])
        return t / np.maximum(np.hypot(t[..., 0], t[..., 1]), 1e-9)[..., None]

    def _stem(self, rng):
        self.P = np.array([[0.0, GROUND + 0.10], [rng.uniform(-.14, .14), -1.0],
                           [rng.uniform(-.14, .14), -0.55], [rng.uniform(-.05, .05), -0.18]])
        n = int(1500 * self.d)
        u = rng.random(n)
        off = rng.uniform(-1, 1, n)
        c = self._bez(u)
        t = self._tan(u)
        w = 0.034 - 0.012 * u
        self.st_u = u
        self.st_pos = c + np.stack([-t[:, 1], t[:, 0]], 1) * (off * w)[:, None]
        self.st_mt = np.clip(0.12 + 0.05 * off + rng.normal(0, 0.02, n), 0.05, 0.2)
        self.st_sz = rng.choice(SIZES, n, p=[0.6, 0.34, 0.06])
        self.st_al = 0.7 + 0.3 * rng.random(n)

    def _leaves(self, rng):
        spec = [(0.13, -1, 0.74, 0.34, 0.55), (0.18, +1, 0.70, 0.30, 0.50),
                (0.38, -1, 0.40, 0.62, 0.35), (0.44, +1, 0.38, 0.58, 0.30)]
        self.leaves = []
        for u, side, L, ang, droop in spec:
            n = int(1500 * self.d)
            kind = rng.choice(3, n, p=[0.40, 0.30, 0.30])
            a = np.where(kind == 0, sample_profile(leaf_w, n, rng), rng.uniform(0.02, 0.98, n))
            v = np.where(kind == 0, rng.uniform(-1, 1, n),
                         np.where(kind == 1, rng.choice([-1.0, 1.0], n), rng.normal(0, 0.02, n)))
            # side veins: pull some of the "kind 2" dots onto diagonal lines
            vein = kind == 2
            k = rng.integers(0, 7, n)
            a = np.where(vein & (rng.random(n) < 0.7), 0.1 + k * 0.12 + rng.random(n) * 0.16, a)
            v = np.where(vein & (a > 0.1) & (np.abs(v) < 0.05),
                         rng.choice([-1.0, 1.0], n) * rng.random(n) * 0.85, v)
            mt = np.where(kind == 0, 0.20, np.where(kind == 1, 0.15, 0.27)) + rng.normal(0, 0.02, n)
            self.leaves.append(dict(u=u, side=side, L=L * rng.uniform(0.92, 1.08), ang=ang, droop=droop,
                                    a=a, v=v, mt=np.clip(mt, 0.1, 0.32),
                                    sz=rng.choice(SIZES, n, p=[0.6, 0.34, 0.06]),
                                    al=np.where(kind == 0, 0.28 + 0.30 * rng.random(n), 0.75 + 0.25 * rng.random(n))))

    def _soil(self, rng):
        n = int(5500 * self.d)
        x = rng.uniform(-1.4, 1.4, n)
        dd = np.minimum(rng.exponential(0.09, n), 0.5)
        top = 0.24 * np.exp(-(x / 0.85) ** 2) + 0.02 * np.sin(x * 23) + 0.012 * np.sin(x * 51 + 1)
        y = GROUND + top - dd + rng.normal(0, 0.012, n) * (dd < 0.03)
        self.so_pos = np.stack([x, y], 1)
        self.so_mt = np.clip(0.0 + 0.035 * (1 - dd / 0.5) + rng.normal(0, 0.012, n), 0.0, 0.06)
        self.so_al = np.clip(0.85 - dd / 0.40, 0.10, 0.9) * (0.5 + 0.5 * rng.random(n))
        self.so_sz = rng.choice(SIZES, n, p=[0.55, 0.35, 0.10])

    def _shell(self, rng):
        g = (1 + 5 ** 0.5) / 2
        axes = np.array([[0, 1, g], [0, 1, -g], [1, g, 0], [1, -g, 0], [g, 0, 1], [-g, 0, 1]], float)
        axes /= np.linalg.norm(axes, axis=1)[:, None]
        q, _ = np.linalg.qr(rng.normal(size=(3, 3)))
        axes = axes @ q
        pts, tw = [], []
        n = int(340 * self.d)
        for ax in axes:
            u = np.cross(ax, rng.normal(size=3)); u /= np.linalg.norm(u)
            w = np.cross(ax, u)
            th = np.linspace(0, TAU, n, endpoint=False) + rng.normal(0, 0.004, n)
            pts.append(np.cos(th)[:, None] * u + np.sin(th)[:, None] * w)
        self.c_pts = np.concatenate(pts)
        self.c_pts *= (1 + rng.normal(0, 0.004, (len(self.c_pts), 1)))
        self.c_al = 0.55 + 0.45 * rng.random(len(self.c_pts))
        self.c_sz = rng.choice(SIZES, len(self.c_pts), p=[0.7, 0.28, 0.02])
        self.c_tw = rng.uniform(0, TAU, len(self.c_pts))
        ns = int(700 * self.d)
        v = rng.normal(size=(ns, 3)); v /= np.linalg.norm(v, axis=1)[:, None]
        self.star = v * rng.uniform(0.96, 1.0, (ns, 1))
        self.star_al = rng.uniform(0.25, 1.0, ns)
        self.star_sz = rng.choice(SIZES, ns, p=[0.8, 0.17, 0.03])
        self.star_tw = rng.uniform(0, TAU, ns)
        nm = int(230 * self.d)
        v = rng.normal(size=(nm, 3)); v /= np.linalg.norm(v, axis=1)[:, None]
        self.mote = v * rng.uniform(0.15, 0.93, (nm, 1))
        self.mote_w = rng.uniform(-0.5, 0.5, nm)
        self.mote_tw = rng.uniform(0, TAU, nm)
        th = np.linspace(0, TAU, int(430 * self.d), endpoint=False)
        self.sil = np.stack([np.cos(th), np.sin(th)], 1)
        self.sil_al = 0.5 + 0.5 * rng.random(len(th))

    # --------------------------------------------------------------- physics
    def pop(self, strength=2.4):
        self.kick_v += strength

    def step_kick(self, dt):
        self.kick_v += (-55.0 * self.kick - 5.5 * self.kick_v) * dt
        self.kick += self.kick_v * dt

    def sway(self, u, t, wind):
        return wind * 0.03 * np.sin(0.9 * t + 2.0 * u) * np.asarray(u) ** 1.6

    def head_pos(self, g, t, wind=1.0):
        sg = float(smooth(g / 0.55))
        c = self._bez(np.array(sg))
        return np.array([float(c[0]) + float(self.sway(sg, t, wind)), float(c[1])])

    # ---------------------------------------------------------------- points
    def points(self, t, g, yaw, tilt, wind=1.0, spin=1.0, soil_fade=1.0):
        d = self.d
        sg = float(smooth(g / 0.55))
        lg = float(smooth((g - 0.10) / 0.45))
        hs = 0.15 + 0.85 * float(smooth((g - 0.18) / 0.62))
        b = float(smooth((g - 0.42) / 0.58))
        pg = float(smooth(g / 0.85))
        head = self.head_pos(g, t, wind)
        kick = self.kick
        P, A, M, S = [], [], [], []

        # soil
        P.append(self.so_pos); A.append(self.so_al * soil_fade); M.append(self.so_mt); S.append(self.so_sz)

        # stem
        vis = self.st_u <= sg
        pos = self.st_pos.copy()
        pos[:, 0] += self.sway(self.st_u, t, wind)
        P.append(pos); A.append(self.st_al * vis); M.append(self.st_mt); S.append(self.st_sz)

        # leaves
        for lf in self.leaves:
            gl = float(smooth((lg - (0.0 if lf["u"] < 0.2 else 0.18)) / 0.6)) * float(smooth((sg - lf["u"]) / 0.12))
            anchor = self._bez(np.array(lf["u"])) + np.array([float(self.sway(lf["u"], t, wind)), 0.0])
            L = lf["L"] * max(gl, 1e-4)
            ang = (1.25 + (lf["ang"] - 1.25) * gl) + 0.04 * np.sin(1.1 * t + lf["u"] * 9) * wind
            a, v, sd, dr = lf["a"], lf["v"], lf["side"], lf["droop"]
            ax = np.array([sd * np.cos(ang), np.sin(ang)])
            base = a[:, None] * ax * L + np.stack([np.zeros_like(a), -dr * L * a * a], 1)
            tg = ax + np.stack([np.zeros_like(a), -2 * dr * a], 1)
            tg /= np.hypot(tg[:, 0], tg[:, 1])[:, None]
            nrm = np.stack([-tg[:, 1], tg[:, 0]], 1)
            p = anchor + base + nrm * (v * leaf_w(a) * 0.26 * L)[:, None]
            P.append(p); A.append(lf["al"] * gl); M.append(lf["mt"]); S.append(lf["sz"])

        # ---- flower head (3D) ----
        br = smooth((b - np.arange(4) * 0.10) / 0.70)
        th0 = (self.row_thc + (self.row_tho - self.row_thc) * br)[self.pROW]
        bend = self.row_bend[self.pROW]
        L = self.row_L[self.pROW] * hs
        W = self.row_W[self.pROW] * hs
        ang_a = th0 + bend * self.pA
        rad_i = (np.cos(th0) - np.cos(ang_a)) / bend
        y_i = (np.sin(ang_a) - np.sin(th0)) / bend
        w = petal_w(self.pA)
        tang = self.pV * W * w
        cup = 0.35 * W * self.pV ** 2 * w
        breathe = 1 + 0.02 * np.sin(1.4 * t + self.pROW * 0.7) + 0.10 * kick * (1 - 0.2 * self.pROW)
        rad = (self.row_r0[self.pROW] * hs + L * rad_i - cup * np.cos(ang_a)) * breathe
        yv = (L * y_i + cup * np.sin(ang_a)) * breathe
        tang = tang * breathe
        phi = self.pPHI
        fx = rad * np.cos(phi) - tang * np.sin(phi)
        fz = rad * np.sin(phi) + tang * np.cos(phi)
        tw = 0.8 + 0.2 * np.sin(2.3 * t + self.pTW)
        fa = self.pAL * tw * float(smooth(sg * 6))
        FX, FY, FZ, FA, FM, FS = [fx], [yv], [fz], [fa], [self.pMT], [self.pSZ]

        # stamens
        sb = float(smooth((b - 0.2) / 0.5)) * hs
        k = self.s_k
        rr = self.s_rr * hs + np.sin(self.s_tl) * k * self.s_len * sb
        sy = 0.02 * hs + np.cos(self.s_tl) * k * self.s_len * sb
        FX.append(rr * np.cos(self.s_phi)); FY.append(sy); FZ.append(rr * np.sin(self.s_phi))
        FA.append((0.5 + 0.5 * np.sin(3.1 * t + self.s_tw)) * 0.55 * sb / max(hs, 1e-3) * float(smooth(sg * 6)))
        FM.append(np.full(len(k), 0.92)); FS.append(self.s_sz)
        dk = self.disk * hs
        FX.append(dk[:, 0]); FY.append(dk[:, 1]); FZ.append(dk[:, 2])
        FA.append((0.25 + 0.25 * np.sin(2.0 * t + self.disk_tw)) * float(smooth(sg * 6)))
        FM.append(np.full(len(dk), 0.84)); FS.append(np.full(len(dk), 1.0))

        FM[0] = np.clip(self.pMT + 0.07 * np.cos(self.pPHI + yaw - 2.0), 0.30, 0.85)        # light from one side
        FX, FY, FZ = np.concatenate(FX), np.concatenate(FY), np.concatenate(FZ)
        x3, y3, z3 = rot(FX, FY, FZ, yaw, tilt)
        px, py, _ = project(x3, y3, z3)
        dep = 0.55 + 0.45 * np.clip((z3 + 0.7) / 1.4, 0, 1)                                 # far side is dimmer
        fpos = np.stack([px + head[0], py + head[1]], 1)
        falpha = np.concatenate(FA) * dep
        npet = len(self.pA)
        self.emit_pos, self.emit_alpha, self.emit_row = fpos[:npet], falpha[:npet], self.pROW
        self.head = head
        P.append(fpos)
        A.append(falpha); M.append(np.concatenate(FM)); S.append(np.concatenate(FS))

        # ---- glass sphere ----
        Rs = (0.2 + 0.8 * pg) * (1 + 0.03 * np.sin(1.1 * t) + 0.12 * kick)
        C = head + np.array([0.0, 0.08 + 0.24 * hs])
        sy_, st_ = 0.22 * spin * t, 0.30 * np.sin(0.13 * t)
        ap = float(smooth(pg * 3))

        def shell(pts3, al, mats, sz, alpha_k):
            x, y, z = rot(pts3[:, 0], pts3[:, 1], pts3[:, 2], sy_, st_)
            x, y, z = rot(x, y, z, yaw, tilt)
            px, py, f = project(x * Rs, y * Rs, z * Rs)
            depth = 0.55 + 0.45 * (z + 1) / 2
            P.append(np.stack([px + C[0], py + C[1]], 1))
            A.append(al * depth * alpha_k * ap); M.append(mats); S.append(sz)

        shell(self.c_pts, self.c_al * (0.75 + 0.25 * np.sin(1.7 * t + self.c_tw)),
              np.full(len(self.c_pts), 1.0), self.c_sz, 0.95)
        shell(self.star, self.star_al * (0.6 + 0.4 * np.sin(2.1 * t + self.star_tw)),
              np.full(len(self.star), 0.98), self.star_sz, 1.0)
        ang = self.mote_w * t
        mx = self.mote[:, 0] * np.cos(ang) + self.mote[:, 2] * np.sin(ang)
        mz = -self.mote[:, 0] * np.sin(ang) + self.mote[:, 2] * np.cos(ang)
        my = self.mote[:, 1] + 0.03 * np.sin(1.3 * t + self.mote_tw)
        shell(np.stack([mx, my, mz], 1), (0.45 + 0.45 * np.sin(2.6 * t + self.mote_tw)).clip(0.05),
              np.full(len(mx), 0.93), np.ones(len(mx)), 0.9)
        P.append(self.sil * Rs + C)
        A.append(self.sil_al * 0.9 * ap); M.append(np.full(len(self.sil), 1.0)); S.append(np.ones(len(self.sil)))

        pos = np.vstack(P).astype(_f)
        return pos, np.concatenate(A).astype(_f), np.concatenate(M).astype(_f), np.concatenate(S).astype(_f)
