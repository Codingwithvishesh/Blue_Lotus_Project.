"""Fireflies rising from the soil and click-burst sparks."""
import numpy as np

_f = np.float32
TAU = 2 * np.pi


class Sparks:
    def __init__(self, n, seed=3):
        self.rng = np.random.default_rng(seed)
        self.n = n
        self.pos = np.zeros((n, 2), _f)
        self.vel = np.zeros((n, 2), _f)
        self.age = np.full(n, 99.0, _f)
        self.life = np.ones(n, _f)
        self.t = 0.0

    def _spawn(self, mask, centre, spread, burst):
        k = int(mask.sum())
        if not k:
            return
        r = self.rng
        self.pos[mask] = np.asarray(centre) + np.stack([r.normal(0, spread, k), r.normal(0, spread * 0.6, k)], 1)
        if burst:
            a = r.uniform(0, TAU, k)
            sp = r.uniform(0.3, 1.3, k)
            self.vel[mask] = np.stack([np.cos(a) * sp, np.sin(a) * sp], 1)
            self.life[mask] = r.uniform(1.2, 3.0, k)
        else:
            self.vel[mask] = np.stack([r.normal(0, 0.04, k), r.uniform(0.06, 0.22, k)], 1)
            self.life[mask] = r.uniform(3.0, 7.0, k)
        self.age[mask] = 0.0

    def emit(self, origins, centre, speed=0.22):
        """Sparkles leaving the flower: born on petal dots, drifting outward and up."""
        dead = np.flatnonzero(self.age >= self.life)
        n = min(len(dead), len(origins))
        if n == 0:
            return
        ids, r = dead[:n], self.rng
        o = np.asarray(origins[:n])
        out = o - np.asarray(centre)
        out /= np.maximum(np.hypot(out[:, 0], out[:, 1]), 1e-6)[:, None]
        self.pos[ids] = o + r.normal(0, 0.01, (n, 2))
        self.vel[ids] = out * r.uniform(0.4, 1.2, (n, 1)) * speed + np.stack(
            [r.normal(0, 0.03, n), r.uniform(0.06, 0.20, n)], 1)
        self.life[ids] = r.uniform(1.6, 3.2, n)
        self.age[ids] = 0.0

    def burst(self, centre, count=150):
        ids = self.rng.choice(self.n, min(count, self.n), replace=False)
        mask = np.zeros(self.n, bool)
        mask[ids] = True
        self._spawn(mask, centre, 0.12, True)

    def step(self, dt, rate, wind=1.0):
        self.t += dt
        self.age += dt
        if rate > 0:                                             # rate = fireflies per second
            n = int(self.rng.poisson(rate * dt))
            dead = np.flatnonzero(self.age >= self.life)
            if n and len(dead):
                mask = np.zeros(self.n, bool)
                mask[dead[:n]] = True
                self._spawn(mask, (0.0, -1.35), 0.9, False)
        self.vel[:, 0] += wind * 0.05 * np.sin(self.t * 0.7 + self.pos[:, 1] * 2.5) * dt
        self.vel *= 1 - 0.3 * dt
        self.pos += self.vel * dt

    def points(self):
        frac = np.clip(self.age / self.life, 0, 1)
        a = np.maximum(np.sin(np.pi * frac), 0.0) ** 1.0 * 1.3 * (self.age < self.life)
        mat = np.full(self.n, 0.96, _f)
        size = np.where(((self.age * 5.0 + self.pos[:, 0] * 7.0) % 1.0) < 0.5, 4.0, 3.0).astype(_f)   # twinkle
        return self.pos, a.astype(_f), mat, size
