"""Blue-only colour system.

A pixel's colour is looked up from (material, intensity).  Materials run along
one axis: soil -> stem -> leaf -> vein -> petals (deep -> icy) -> stamen -> star.
Every key colour keeps B >= G >= R, so nothing can leave the blue family.
"""
import numpy as np

MATS = 32
KEYS = [0.00, 0.12, 0.20, 0.27, 0.36, 0.58, 0.78, 0.90, 1.00]
NAMES = ["soil", "stem", "leaf", "vein", "petal_out", "petal_mid", "petal_in", "stamen", "star"]

THEMES = {
    "electric": dict(soil=(26, 58, 108), stem=(22, 76, 214), leaf=(34, 104, 228), vein=(0, 176, 255),
                     petal_out=(18, 60, 226), petal_mid=(40, 136, 255), petal_in=(140, 210, 255),
                     stamen=(205, 238, 255), star=(236, 248, 255)),
    "ice":      dict(soil=(40, 66, 104), stem=(70, 118, 200), leaf=(90, 148, 222), vein=(120, 210, 255),
                     petal_out=(70, 120, 215), petal_mid=(120, 175, 240), petal_in=(180, 222, 255),
                     stamen=(235, 247, 255), star=(245, 251, 255)),
    "sapphire": dict(soil=(14, 30, 78), stem=(14, 40, 168), leaf=(24, 62, 194), vein=(30, 140, 245),
                     petal_out=(10, 30, 172), petal_mid=(40, 90, 240), petal_in=(110, 160, 255),
                     stamen=(180, 205, 255), star=(214, 230, 255)),
    "azure":    dict(soil=(10, 52, 90), stem=(0, 100, 190), leaf=(0, 130, 205), vein=(40, 220, 255),
                     petal_out=(0, 100, 205), petal_mid=(10, 170, 255), petal_in=(110, 225, 255),
                     stamen=(190, 242, 255), star=(225, 250, 255)),
}
THEME_ORDER = list(THEMES)


def build_lut(name):
    """Flat (MATS*256,) uint32 table, index = material*256 + intensity."""
    th = THEMES[name]
    keys = np.array([th[n] for n in NAMES], float)
    mpos = np.arange(MATS) / (MATS - 1)
    base = np.stack([np.interp(mpos, KEYS, keys[:, c]) for c in range(3)], 1)      # (MATS, 3)
    I = np.linspace(0, 1, 256)[None, :, None]
    col = base[:, None, :] * I ** 0.75 + 255 * 0.28 * I ** 5
    col = np.minimum(col, 255)
    table = np.zeros((MATS, 256, 4), np.uint8)
    table[..., :3] = col
    return table.reshape(-1, 4).copy().view(np.uint32).reshape(-1)


def lut_rgb(name):
    return build_lut(name).view(np.uint8).reshape(MATS, 256, 4)[..., :3]
