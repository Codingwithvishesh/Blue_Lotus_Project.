"""Blue Lotus - a pointillism flower engine."""
__version__ = "1.0.0"
