from dataclasses import dataclass


@dataclass
class Config:
    # window / output
    width: int = 540
    height: int = 960
    fps: int = 60
    fullscreen: bool = False

    # look
    theme: str = "electric"
    bloom: bool = True
    hud: bool = True
    span: float = 0.90            # screen width covered by 2 world units
    y_anchor: float = -0.17       # world y shown at screen centre
    trail: float = 0.28
    exposure: float = 1.6

    # flower
    seed: int = 5
    time_scale: float = 3.0       # 3 -> full bloom in 15 s (the keyframes span 45 s)
    loop: bool = False            # grow -> hold -> shrink -> regrow
    hold_seconds: float = 4.0
    density: float = 1.0          # dot count multiplier
    wind: float = 1.0
    spin: float = 1.0
    sparks: int = 700
    sparkle_idle: float = 12.0     # sparkles per second from an open flower
    sparkle_growth: float = 700.0  # extra per unit of growth speed (about 50/s while blooming)
