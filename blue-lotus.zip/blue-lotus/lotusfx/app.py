"""Interactive window + offline video export."""
import os
import time
from datetime import datetime

import numpy as np

from .palette import THEME_ORDER
from .recorder import Recorder
from .scene import Scene


def export_video(cfg, path, seconds):
    """Headless, deterministic render -> MP4 (no window needed)."""
    scene = Scene(cfg)
    rec = Recorder(path, cfg.width, cfg.height, cfg.fps)
    dt, frames, t0 = 1.0 / cfg.fps, int(seconds * cfg.fps), time.time()
    try:
        for f in range(frames):
            scene.step(dt)
            rec.write(scene.render())
            if f % cfg.fps == 0:
                print(f"\r  rendering {f / cfg.fps:5.1f}s / {seconds:.1f}s", end="", flush=True)
    finally:
        rec.close()
    print(f"\r  done in {time.time() - t0:.1f}s -> {path}            ")


def run(cfg):
    import pygame
    from .hud import Hud

    pygame.init()
    flags = pygame.SCALED | pygame.RESIZABLE | (pygame.FULLSCREEN if cfg.fullscreen else 0)
    screen = pygame.display.set_mode((cfg.width, cfg.height), flags)
    pygame.display.set_caption("Blue Lotus - Pointillism Flower")
    clock, hud = pygame.time.Clock(), Hud()
    scene = Scene(cfg)
    theme_i = THEME_ORDER.index(cfg.theme)
    recorder, paused, fps_s = None, False, float(cfg.fps)
    os.makedirs("recordings", exist_ok=True)
    os.makedirs("screenshots", exist_ok=True)
    stamp = lambda: datetime.now().strftime("%Y%m%d_%H%M%S")

    running = True
    while running:
        dt = clock.tick(cfg.fps) / 1000.0
        dt = 1.0 / cfg.fps if recorder else min(dt, 1 / 20)

        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                running = False
            elif e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
                scene.burst()
            elif e.type == pygame.KEYDOWN:
                k = e.key
                if k in (pygame.K_ESCAPE, pygame.K_q):
                    running = False
                elif k == pygame.K_SPACE:
                    scene.replay()
                elif k == pygame.K_n:
                    scene.new_flower()
                elif k == pygame.K_l:
                    scene.toggle_loop()
                elif k == pygame.K_LEFT:
                    scene.seek(-2.0)
                elif k == pygame.K_RIGHT:
                    scene.seek(2.0)
                elif k in (pygame.K_PLUS, pygame.K_EQUALS, pygame.K_KP_PLUS):
                    scene.speed(1.25)
                elif k in (pygame.K_MINUS, pygame.K_KP_MINUS):
                    scene.speed(0.8)
                elif k == pygame.K_p:
                    paused = not paused
                elif k == pygame.K_a:
                    scene.auto_spin = not scene.auto_spin
                elif k == pygame.K_t:
                    theme_i = (theme_i + 1) % len(THEME_ORDER)
                    cfg.theme = THEME_ORDER[theme_i]
                    scene.renderer.set_theme(cfg.theme)
                elif k == pygame.K_b:
                    cfg.bloom = not cfg.bloom
                elif k == pygame.K_h:
                    cfg.hud = not cfg.hud
                elif k == pygame.K_f:
                    pygame.display.toggle_fullscreen()
                elif k == pygame.K_s and scene.renderer.last is not None:
                    shot = pygame.surfarray.make_surface(np.ascontiguousarray(scene.renderer.last).swapaxes(0, 1))
                    path = f"screenshots/blue_lotus_{stamp()}.png"
                    pygame.image.save(shot, path)
                    print("saved", path)
                elif k == pygame.K_r:
                    if recorder:
                        recorder.close()
                        print("saved", recorder.path)
                        recorder = None
                    else:
                        try:
                            recorder = Recorder(f"recordings/blue_lotus_{stamp()}.mp4", cfg.width, cfg.height, cfg.fps)
                        except Exception as ex:
                            print("recording unavailable:", ex)

        look = None
        if pygame.mouse.get_focused():
            mx, my = pygame.mouse.get_pos()
            w, h = screen.get_size()
            look = (mx / w * 2 - 1, my / h * 2 - 1)
        if not paused:
            scene.step(dt, look)

        frame = scene.render()
        pygame.surfarray.blit_array(screen, np.ascontiguousarray(frame).swapaxes(0, 1))
        if recorder:
            recorder.write(frame)
        fps_s += (clock.get_fps() - fps_s) * 0.1
        if cfg.hud:
            hud.draw(screen, fps_s, scene.dots, scene.seed, cfg.theme, bool(recorder),
                     scene.bloomed, scene.timeline.loop, scene.timeline.ts)
        pygame.display.flip()

    if recorder:
        recorder.close()
    pygame.quit()
