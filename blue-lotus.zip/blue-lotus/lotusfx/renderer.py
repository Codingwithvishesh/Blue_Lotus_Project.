"""Pure numpy stipple renderer: sized dot splatting, trails, bloom, blue LUT."""
import numpy as np

from .palette import MATS, build_lut

_f = np.float32


def _blur(a):
    p = np.pad(a, 1, mode="edge")
    a = (p[:-2, 1:-1] + 2 * p[1:-1, 1:-1] + p[2:, 1:-1]) / 4
    p = np.pad(a, 1, mode="edge")
    return (p[1:-1, :-2] + 2 * p[1:-1, 1:-1] + p[1:-1, 2:]) / 4


def _axis(src_n, dst_n):
    pos = (np.arange(dst_n) + 0.5) * src_n / dst_n - 0.5
    i0 = np.clip(np.floor(pos).astype(int), 0, src_n - 1)
    i1 = np.clip(i0 + 1, 0, src_n - 1)
    return i0, i1, np.clip(pos - i0, 0, 1).astype(_f)


class Renderer:
    def __init__(self, cfg):
        self.cfg = cfg
        self.W, self.H = cfg.width, cfg.height
        self.S = self.W * cfg.span / 2.0                        # pixels per world unit
        self.cx, self.cy = self.W / 2.0, self.H / 2.0
        shape = (self.H, self.W)
        self.acc = np.zeros(shape, _f)
        self.accm = np.zeros(shape, _f)
        self._tmp = np.zeros(shape, _f)
        self._mtmp = np.zeros(shape, _f)
        self.k = max(1, int(round(self.W / 540)))               # dot-size unit in pixels
        self.G = 4 * self.k + 1                                 # guard border (covers glint arms)
        self.f1 = max(2, int(round(self.W / 135)))
        self._maps = {}
        self.last = None
        self.set_theme(cfg.theme)

    def set_theme(self, name):
        self.lut32 = build_lut(name)

    def extent(self):
        return self.W / (2 * self.S), self.H / (2 * self.S)

    def screen_to_unit(self, px, py):
        return (px - self.cx) / self.S, (self.cy - py) / self.S + self.cfg.y_anchor

    def reset(self):
        self.acc[:] = 0
        self.accm[:] = 0

    # ----------------------------------------------------------------- splat
    def _splat(self, pos, alpha, mat, size):
        W, H, G, k = self.W, self.H, self.G, self.k
        W2, H2 = W + 2 * G, H + 2 * G
        X = np.clip(self.cx + pos[:, 0] * self.S, -G + 3 * k, W + G - 2 - 3 * k)
        Y = np.clip(self.cy - (pos[:, 1] - self.cfg.y_anchor) * self.S, -G + 3 * k, H + G - 2 - 3 * k)
        x0, y0 = np.floor(X), np.floor(Y)
        fx, fy = X - x0, Y - y0
        i00 = (y0 + G).astype(np.int32) * W2 + (x0 + G).astype(np.int32)

        idx = [i00, i00 + 1, i00 + W2, i00 + W2 + 1]
        w = [alpha * (1 - fx) * (1 - fy), alpha * fx * (1 - fy), alpha * (1 - fx) * fy, alpha * fx * fy]
        mt = [mat] * 4

        big = size >= 1.5                                       # plus-shaped dot
        if big.any():
            ib, ab, mb = i00[big], alpha[big] * 0.5, mat[big]
            for off in (k, -k, k * W2, -k * W2):
                idx.append(ib + off); w.append(ab); mt.append(mb)
        huge = size >= 2.5                                      # diagonals -> round 3px dot
        if huge.any():
            ib, ab, mb = i00[huge], alpha[huge] * 0.38, mat[huge]
            for off in (k + k * W2, k - k * W2, -k + k * W2, -k - k * W2):
                idx.append(ib + off); w.append(ab); mt.append(mb)

        glint = size >= 3.5                                     # 4-point star: long cross arms
        if glint.any():
            ib, ab, mb = i00[glint], alpha[glint] * 0.55, mat[glint]
            for off in (2 * k, -2 * k, 2 * k * W2, -2 * k * W2):
                idx.append(ib + off); w.append(ab); mt.append(mb)
            ab2 = alpha[glint] * 0.30
            for off in (3 * k, -3 * k, 3 * k * W2, -3 * k * W2):
                idx.append(ib + off); w.append(ab2); mt.append(mb)

        idx = np.concatenate(idx)
        w = np.concatenate(w)
        mw = w * np.concatenate(mt)
        n = W2 * H2
        a = np.bincount(idx, weights=w, minlength=n).reshape(H2, W2)[G:-G, G:-G]
        m = np.bincount(idx, weights=mw, minlength=n).reshape(H2, W2)[G:-G, G:-G]
        return a, m

    # -------------------------------------------------------- resampling
    def _reduce(self, a, f):
        H, W = a.shape
        a = np.pad(a, ((0, (-H) % f), (0, (-W) % f)))
        return a.reshape(a.shape[0] // f, f, a.shape[1] // f, f).mean((1, 3))

    def _up(self, a, f, shape):
        key = (a.shape, f)
        if key not in self._maps:
            self._maps[key] = (_axis(a.shape[0], a.shape[0] * f), _axis(a.shape[1], a.shape[1] * f))
        (r0, r1, rw), (c0, c1, cw) = self._maps[key]
        rows = a[r0] * (1 - rw)[:, None] + a[r1] * rw[:, None]
        out = rows[:, c0] * (1 - cw)[None, :] + rows[:, c1] * cw[None, :]
        return out[: shape[0], : shape[1]]

    def _bloom(self, img):
        a = self._reduce(img, self.f1)
        for _ in range(3):
            a = _blur(a)
        c = self._reduce(a, 4)
        for _ in range(2):
            c = _blur(c)
        mixed = 0.45 * a + 0.35 * self._up(c, 4, a.shape)
        return self._up(mixed, self.f1, img.shape)

    def _material(self):
        """Exact per-dot colour where dots are; the glow halo uses a neutral mid-blue."""
        sharp = np.divide(self.accm, self.acc + 1e-4, out=self._mtmp)
        return np.where(self.acc > 0.03, sharp, 0.62)

    # ---------------------------------------------------------------- render
    def render(self, pos, alpha, mat, size, bloom=None):
        cfg = self.cfg
        self.acc *= cfg.trail
        self.accm *= cfg.trail
        a, m = self._splat(pos, alpha, mat, size)
        self.acc += a
        self.accm += m

        img = np.multiply(self.acc, -cfg.exposure, out=self._tmp)
        np.exp(img, out=img)
        np.subtract(1.0, img, out=img)
        mat_map = self._material()
        if cfg.bloom if bloom is None else bloom:
            img += self._bloom(img)
        np.clip(img, 0.0, 1.0, out=img)
        inten = (img * 255.0).astype(np.uint16)
        mi = (np.clip(mat_map, 0, 1) * (MATS - 1) + 0.5).astype(np.uint16)
        packed = np.ascontiguousarray(self.lut32[(mi << 8) + inten])
        frame = packed.view(np.uint8).reshape(self.H, self.W, 4)[..., :3]
        self.last = frame
        return frame
