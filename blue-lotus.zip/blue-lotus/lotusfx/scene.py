"""Ties lotus + sparks + camera + timeline together (window and exporter share it)."""
import numpy as np

from .lotus import Lotus
from .renderer import Renderer
from .sparks import Sparks
from .timeline import Timeline


class Scene:
    def __init__(self, cfg):
        self.cfg = cfg
        self.renderer = Renderer(cfg)
        self.seed = cfg.seed
        self.auto_spin = True
        self.yaw = 0.0
        self.tilt = 0.68
        self._build()

    def _build(self):
        cfg = self.cfg
        self.lotus = Lotus(self.seed, cfg.density)
        self.sparks = Sparks(cfg.sparks, self.seed)
        self.timeline = Timeline(cfg.time_scale, cfg.loop, cfg.hold_seconds)
        self.t = 0.0
        self._g_prev = 0.0
        self._emit_acc = 0.0
        self.renderer.reset()

    # --------------------------------------------------------------- control
    def replay(self):
        self._build()

    def new_flower(self):
        self.seed += 1
        self._build()

    def toggle_loop(self):
        self.timeline.loop = not self.timeline.loop
        self.cfg.loop = self.timeline.loop

    def speed(self, factor):
        self.timeline.ts = float(np.clip(self.timeline.ts * factor, 0.5, 12.0))

    def seek(self, seconds):
        self.timeline.seek(seconds)

    def burst(self):
        self.lotus.pop()
        c = self.lotus.head_pos(self.timeline.g, self.t, self.cfg.wind)
        self.sparks.burst(c + np.array([0.0, 0.3]))

    @property
    def bloomed(self):
        return self.timeline.percent

    @property
    def dots(self):
        return len(self.last_count) if hasattr(self, "last_count") else 0

    # ------------------------------------------------------------------ step
    def step(self, dt, look=None):
        """look = (nx, ny) in [-1, 1] from the pointer, or None for the auto orbit."""
        cfg = self.cfg
        self.t += dt
        self.timeline.step(dt)
        if look is None:
            ty, tt = 0.38 * np.sin(0.35 * self.t), 0.68 + 0.05 * np.sin(0.27 * self.t + 1.0)
        else:
            ty, tt = look[0] * 0.9, 0.68 + look[1] * 0.30
        k = 1 - np.exp(-4.0 * dt)
        self.yaw += (ty - self.yaw) * k
        self.tilt += (tt - self.tilt) * k
        self.lotus.step_kick(dt)
        self.sparks.step(dt, 6.0 if self.timeline.g > 0.6 else 0.0, cfg.wind)
        self._emit_from_flower(dt)

    def _emit_from_flower(self, dt):
        """A few sparkles drift off the petals while the lotus grows (a trickle once it is open)."""
        g = self.timeline.g
        grow = abs(g - self._g_prev) / max(dt, 1e-4)                   # growth speed per second
        self._g_prev = g
        alive = float(np.clip((g - 0.20) / 0.20, 0, 1))                # only once a flower exists
        rate = alive * (self.cfg.sparkle_idle + self.cfg.sparkle_growth * grow)
        self._emit_acc += rate * dt
        n = int(self._emit_acc)
        self._emit_acc -= n
        lo = self.lotus
        if n <= 0 or len(lo.emit_pos) == 0:
            return
        ok = np.flatnonzero((lo.emit_alpha > 0.35) & (lo.emit_row <= 1))   # outer two petal rows
        if len(ok) == 0:
            return
        pick = self.sparks.rng.choice(ok, min(n, len(ok)), replace=False)
        self.sparks.emit(lo.emit_pos[pick], lo.head + np.array([0.0, 0.1]))

    def render(self):
        cfg = self.cfg
        spin = cfg.spin if self.auto_spin else 0.0
        p1, a1, m1, s1 = self.lotus.points(self.t, self.timeline.g, self.yaw, self.tilt, cfg.wind, spin,
                                           soil_fade=min(1.0, self.t / 1.5))
        p2, a2, m2, s2 = self.sparks.points()
        pos = np.vstack([p1, p2])
        self.last_count = a1
        return self.renderer.render(pos, np.concatenate([a1, a2]), np.concatenate([m1, m2]),
                                    np.concatenate([s1, s2]))
