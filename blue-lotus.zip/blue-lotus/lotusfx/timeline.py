"""Growth timeline: keyframes (seconds -> growth 0..1), loop and scrub."""
import numpy as np

KEY_T = np.array([0.0, 5.0, 10.0, 16.0, 24.0, 30.0, 39.0, 45.0])
KEY_G = np.array([0.0, 0.06, 0.16, 0.34, 0.58, 0.78, 0.93, 1.0])
T_END = float(KEY_T[-1])


class Timeline:
    def __init__(self, time_scale=3.0, loop=False, hold=4.0):
        self.ts, self.loop, self.hold = time_scale, loop, hold
        self.reset()

    def reset(self):
        self.clock, self.mode, self.wait = 0.0, "grow", 0.0

    def step(self, dt):
        if self.mode == "grow":
            self.clock = min(T_END, self.clock + dt * self.ts)
            if self.clock >= T_END:
                self.mode, self.wait = "hold", 0.0
        elif self.mode == "hold":
            if self.loop:
                self.wait += dt
                if self.wait >= self.hold:
                    self.mode = "shrink"
        elif self.mode == "shrink":
            self.clock = max(0.0, self.clock - dt * self.ts * 1.6)
            if self.clock <= 0.0:
                self.mode, self.wait = "rest", 0.0
        else:                                                   # rest
            self.wait += dt
            if self.wait >= 1.0:
                self.mode = "grow"

    def seek(self, seconds):
        self.clock = float(np.clip(self.clock + seconds * self.ts, 0.0, T_END))
        self.mode = "hold" if self.clock >= T_END else "grow"

    @property
    def g(self):
        lin = float(np.interp(self.clock, KEY_T, KEY_G))
        s = lin * lin * (3 - 2 * lin)
        return 0.5 * lin + 0.5 * s

    @property
    def percent(self):
        return 100.0 * self.g
