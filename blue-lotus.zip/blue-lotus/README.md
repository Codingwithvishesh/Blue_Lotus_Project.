# 🪷 Blue Lotus: Pointillism Flower

Python se bana ek **stipple (pointillism) blue lotus**: mitti me se ek chhota sa bud nikalta hai,
stem upar uthta hai, leaves khulte hain, aur uske charon taraf ek **ghoomta hua dotted glass sphere**
banta hai. Phir petals ek-ek tier me khulkar poora lotus ban jata hai. Sab kuch **sirf blue** shades me.

Pura engine **numpy** par chalta hai (~30,000 dots har frame me), window ke liye **pygame-ce**,
aur Reels ke liye direct **MP4 export**.

---

## ✨ Features

| Feature | Details |
|---|---|
| **Blue-only color system** | 4 themes (`electric`, `ice`, `sapphire`, `azure`). Har color me `B ≥ G ≥ R`, test se verify hota hai. |
| **Pointillism rendering** | Har cheez alag-alag dots (1 to 3 px) se bani hai, har dot ka apna rang aur brightness. |
| **45-second growth timeline** | Keyframes: seed → bud → stem → leaves → bloom. `--time-scale 3` = 15 sec me poora bloom. |
| **4 tier lotus** | 4 rows ke petals (outer droop, inner cup), stamens, aur glowing core. |
| **Glass sphere** | 6 great circles (icosahedral), stars aur orbiting motes, 3D me ghoomta hai aur flower ke saath badhta hai. |
| **Loop mode** | Grow → hold → shrink → regrow, bilkul reel wale effect jaisa. |
| **Flower sparkles** | Growth ke dauraan petals se star-glint sparkles nikalte hain (~50 per sec), bloom ke baad halka sa trickle. |
| **Interactive** | Mouse se 3D tilt, click se pulse + spark burst, timeline scrub. |
| **Procedural seeds** | Har `--seed` ek alag lotus (petal count, stem curve, leaf angles, sphere orientation). |
| **Record / Export** | Live `R` se record, ya bina window ke 1080x1920 Reel render. |
| **Tests** | `pytest`: blue-only colors, deterministic seeds, growth, timeline loop, scene reset. |

---

## 🚀 Install

Python 3.9+ chahiye.

```bash
python -m pip install numpy pygame-ce imageio-ffmpeg
```

(ya project folder me: `python -m pip install -e .`)

> `imageio-ffmpeg` apna ffmpeg saath laata hai, alag se install nahi karna.

## ▶️ Run

```bash
python main.py
```

### Controls

| Key / Mouse | Action |
|---|---|
| **Mouse move** | Lotus aur sphere ko 3D me tilt karo |
| **Left click** | Pulse + spark burst |
| **SPACE** | Growth dobara shuru |
| **N** | Naya lotus (next seed) |
| **L** | Loop mode on/off (grow → hold → shrink → regrow) |
| **← / →** | Timeline me 2 sec peeche / aage |
| **+ / -** | Growth speed badhao / ghatao |
| **T** | Theme badlo |
| **B** | Glow on/off |
| **A** | Sphere spin on/off |
| **P** | Pause |
| **H** | HUD on/off |
| **S** | Screenshot → `screenshots/` |
| **R** | Recording start/stop → `recordings/` |
| **F** | Fullscreen |
| **ESC / Q** | Quit |

## 🎬 Instagram Reel export (bina window ke)

```bash
python main.py --export reel.mp4 --seconds 16 --size 1080x1920 --fps 30
```

Loop wala reel (bloom, fir shrink, fir regrow):

```bash
python main.py --export reel_loop.mp4 --seconds 30 --size 1080x1920 --fps 30 --loop --theme sapphire
```

```
--size 1080x1920     output size (even numbers)
--fps 30             frames per second
--seconds 16         video length
--seed 7             alag lotus
--theme sapphire     electric | ice | sapphire | azure
--time-scale 3       3 = 15 sec me bloom, 1 = poore 45 sec
--density 0.8        dots kam = tez render
--loop               grow, hold, shrink, regrow
--no-bloom           glow band
```

Export deterministic hai: same seed = same video. 1080p par lagbhag
**0.3 sec/frame** lagta hai (16 sec ka reel ≈ 2-3 minute, apni machine par alag ho sakta hai).

---

## 🧠 Kaise kaam karta hai

**Growth.** `timeline.py` ke keyframes (`0, 5, 10, 16, 24, 30, 39, 45` sec) ek growth value `g` (0 se 1)
deti hain. Usse alag-alag progress nikalte hain: stem, leaves, bud size, petal opening, sphere radius.

**Petals.** Har petal ek parametric surface hai: `a` = lambai ke saath, `v` = chaudai ke saath.
Opening angle `θ(a) = θ0 + bend·a`, aur position uska closed-form integral hai, isliye outer
petals neeche jhukte hain aur inner petals andar ki taraf cup banate hain. Dots ko petal ke
**area, outline aur midrib** me baanta gaya hai, tabhi outline saaf dikhta hai.

**Sparkles.** Har frame growth speed (`dg/dt`) naapte hain; jitni tez growth, utne zyada sparkles. Naye sparkle outer petal ke kisi random dot par paida hota hai, bahar aur upar ki taraf udta hai, aur 4-point star ki tarah twinkle karta hai.

**Sphere.** 6 great circles icosahedron ke axes par, 3D me rotate hote hain, aur perspective se project.
Paas wale dots zyada bright, door wale dim.

**Rendering.** Har dot bilinear splat hota hai (bade dots plus/diagonal kernel se), do buffers me:
*intensity* aur *material*. Tone-map `1 - exp(-x)`, bloom, aur `(material, intensity)` se blue LUT.
Material axis: `soil → stem → leaf → vein → petals (deep → icy) → stamen → star`.

## 📁 Structure

```
blue-lotus/
├── main.py              CLI entry point
├── pyproject.toml       dependencies
├── README.md
├── lotusfx/
│   ├── config.py        saari settings (dataclass)
│   ├── palette.py       blue-only themes + LUT
│   ├── timeline.py      growth keyframes, loop, scrub
│   ├── lotus.py         petals, stamens, stem, leaves, soil, sphere
│   ├── sparks.py        fireflies + click burst
│   ├── renderer.py      sized dot splat, trails, bloom, colour
│   ├── scene.py         lotus + sparks + camera + timeline
│   ├── app.py           pygame window + video export
│   ├── recorder.py      ffmpeg pipe (H.264 MP4)
│   └── hud.py           on-screen help
└── tests/test_core.py
```

## 🎛️ Tuning

`lotusfx/config.py` me:

| Setting | Effect |
|---|---|
| `time_scale` | Bloom ki speed |
| `density` | Dots ki ginti (kam = fast, zyada = rich) |
| `trail` | 0 = crisp dots, 0.9 = smear |
| `exposure` | Poora flower kitna bright |
| `wind`, `spin` | Stem sway aur sphere rotation |
| `sparks` | Sparkle pool ka size |
| `sparkle_growth` | Bloom ke dauraan sparkles kitne zyada nikle (0 = band) |
| `sparkle_idle` | Khule flower se sparkles per second |

Petals ki shape `lotusfx/lotus.py` ke `_petals()` me hai (`row_L`, `row_W`, `row_tho`, `row_bend`).

## ✅ Tests

```bash
python -m pip install pytest
python -m pytest tests
```

## 🛠️ Troubleshooting

- **`No module named pygame`** → `python -m pip install pygame-ce`
- **`ffmpeg not found`** → `python -m pip install imageio-ffmpeg`
- **Low FPS** → `python main.py --density 0.6` ya `--no-bloom`
- **Window bahut bada** → `--size 450x800`
- **Video size error** → width/height **even** honi chahiye
