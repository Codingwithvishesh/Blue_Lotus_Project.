"""Blue Lotus - entry point.

  python main.py                                            interactive window
  python main.py --export reel.mp4 --seconds 15 --size 1080x1920 --fps 30
"""
import argparse

from lotusfx.config import Config
from lotusfx.palette import THEMES


def parse():
    ap = argparse.ArgumentParser(description="Blue Lotus - pointillism flower")
    ap.add_argument("--size", default="540x960", help="WIDTHxHEIGHT, even numbers (default 540x960)")
    ap.add_argument("--fps", type=int, default=None)
    ap.add_argument("--seed", type=int, default=5, help="different seed = different lotus")
    ap.add_argument("--theme", default="electric", choices=list(THEMES))
    ap.add_argument("--time-scale", type=float, default=3.0, help="3 = full bloom in 15 s, 1 = 45 s")
    ap.add_argument("--density", type=float, default=1.0, help="dot count multiplier (0.6 = faster)")
    ap.add_argument("--loop", action="store_true", help="grow, hold, shrink, regrow forever")
    ap.add_argument("--no-bloom", action="store_true", help="disable the glow pass")
    ap.add_argument("--fullscreen", action="store_true")
    ap.add_argument("--export", metavar="FILE.mp4", help="render to video, no window")
    ap.add_argument("--seconds", type=float, default=16.0, help="export length")
    return ap.parse_args()


def main():
    a = parse()
    w, h = (int(v) for v in a.size.lower().split("x"))
    cfg = Config(width=w, height=h, seed=a.seed, theme=a.theme, time_scale=a.time_scale,
                 density=a.density, loop=a.loop, bloom=not a.no_bloom, fullscreen=a.fullscreen)
    cfg.fps = a.fps or (30 if a.export else 60)
    from lotusfx import app
    if a.export:
        app.export_video(cfg, a.export, a.seconds)
    else:
        app.run(cfg)


if __name__ == "__main__":
    main()
