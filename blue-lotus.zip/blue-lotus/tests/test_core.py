import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from lotusfx.config import Config
from lotusfx.lotus import Lotus
from lotusfx.palette import THEMES, lut_rgb
from lotusfx.scene import Scene
from lotusfx.timeline import T_END, Timeline


def small_cfg(**kw):
    return Config(width=270, height=480, fps=30, density=0.5, **kw)


def test_every_theme_is_blue_only():
    for name in THEMES:
        rgb = lut_rgb(name).astype(int)
        assert (rgb[..., 2] >= rgb[..., 1]).all(), name
        assert (rgb[..., 1] >= rgb[..., 0]).all(), name


def test_points_are_finite_and_deterministic():
    a = Lotus(seed=4, density=0.5).points(5.0, 0.7, 0.2, 0.5)
    b = Lotus(seed=4, density=0.5).points(5.0, 0.7, 0.2, 0.5)
    for x, y in zip(a, b):
        assert np.isfinite(x).all()
        assert np.allclose(x, y)


def test_growth_reveals_more_dots():
    lo = Lotus(seed=2, density=0.5)
    early = (lo.points(1.0, 0.05, 0, 0.5)[1] > 0.05).sum()
    late = (lo.points(9.0, 1.0, 0, 0.5)[1] > 0.05).sum()
    assert late > early * 2


def test_timeline_grows_loops_and_scrubs():
    tl = Timeline(time_scale=3.0, loop=True, hold=1.0)
    gs = []
    for _ in range(40 * 30):
        tl.step(1 / 30)
        gs.append(tl.g)
    assert max(gs) > 0.99 and min(gs[200:]) < 0.05        # bloomed, then shrank again
    tl.reset()
    tl.seek(100)
    assert tl.clock == T_END and tl.g > 0.99
    tl.seek(-100)
    assert tl.clock == 0.0


def test_rendered_frames_are_blue_only():
    sc = Scene(small_cfg())
    for _ in range(120):
        sc.step(1 / 30)
        frame = sc.render()
    f = np.asarray(frame).astype(int)
    assert f.shape == (480, 270, 3)
    assert (f[..., 2] >= f[..., 1]).all() and (f[..., 1] >= f[..., 0]).all()
    assert f.max() > 100


def test_replay_and_new_flower_reset():
    sc = Scene(small_cfg())
    sc.step(1.0)
    sc.replay()
    assert sc.t == 0.0 and sc.timeline.clock == 0.0
    seed = sc.seed
    sc.new_flower()
    assert sc.seed == seed + 1
